document.addEventListener('DOMContentLoaded', () => {
    const historyContent = document.getElementById('history-content');
    const clearHistoryBtn = document.getElementById('clear-history');

    const history = JSON.parse(localStorage.getItem('chatHistory')) || [];

    if (history.length === 0) {
        historyContent.innerHTML = '<p>ยังไม่มีประวัติการสนทนา</p>';
    } else {
        history.reverse().forEach((conversation, index) => {
            const conversationDiv = document.createElement('div');
            conversationDiv.classList.add('conversation');

            const title = document.createElement('h3');
            title.textContent = `การสนทนาที่ ${history.length - index}`;
            conversationDiv.appendChild(title);

            conversation.forEach(msg => {
                const p = document.createElement('p');
                p.innerHTML = `<strong class="${msg.sender === 'user' ? 'user-q' : ''}">${msg.sender === 'user' ? 'คุณ' : 'บอท'}:</strong> ${msg.message}`;
                conversationDiv.appendChild(p);
            });

            historyContent.appendChild(conversationDiv);
        });
    }

    clearHistoryBtn.addEventListener('click', () => {
        if (confirm('คุณต้องการลบประวัติการสนทนาทั้งหมดใช่หรือไม่?')) {
            localStorage.removeItem('chatHistory');
            historyContent.innerHTML = '<p>ประวัติการสนทนาทั้งหมดถูกลบแล้ว</p>';
        }
    });
});