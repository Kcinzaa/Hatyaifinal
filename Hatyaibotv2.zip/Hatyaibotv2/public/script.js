const chatForm = document.getElementById('chat-form');
const chatInput = document.getElementById('chat-input');
const chatBox = document.getElementById('chat-box');

// โหลดประวัติการสนทนาปัจจุบัน หรือเริ่มใหม่
let currentConversation = [];

function addMessage(message, sender) {
    const messageElement = document.createElement('div');
    messageElement.classList.add('message', sender);
    
    const pElement = document.createElement('p');
    pElement.textContent = message;
    messageElement.appendChild(pElement);

    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight;

    // บันทึกข้อความลงใน session ปัจจุบัน
    currentConversation.push({ sender, message });
}

async function getBotResponse(userMessage) {
    try {
        const response = await fetch('/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ message: userMessage }),
        });
        const data = await response.json();
        addMessage(data.reply, 'bot');
    } catch (error) {
        console.error('Error:', error);
        addMessage('ขออภัยครับ เกิดข้อผิดพลาดในการเชื่อมต่อ', 'bot');
    }
}

chatForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const userMessage = chatInput.value.trim();
    if (!userMessage) return;

    addMessage(userMessage, 'user');
    chatInput.value = '';
    
    getBotResponse(userMessage);
});

// บันทึกการสนทนาเมื่อปิดหน้าต่าง
window.addEventListener('beforeunload', () => {
    if (currentConversation.length > 0) {
        const history = JSON.parse(localStorage.getItem('chatHistory')) || [];
        history.push(currentConversation);
        localStorage.setItem('chatHistory', JSON.stringify(history));
    }
});